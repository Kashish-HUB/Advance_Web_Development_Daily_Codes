//Given an array of numbers, write a function to return the maximum and minimum values.
function findMinMax(arr) {
    return {
        min: Math.min(...arr),
        max: Math.max(...arr)
    };
}

console.log(findMinMax([3, 7, 2, 9, 5])); 
console.log(findMinMax([-10, 0, 20, 5])); 
