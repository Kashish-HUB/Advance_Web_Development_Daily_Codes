//Write a function to merge 2 arrays and remove duplicate elements.
function mergeAndRemoveDuplicates(arr1, arr2) {
    return [...new Set([...arr1, ...arr2])];
}
console.log(mergeAndRemoveDuplicates([1, 2, 3], [3, 4, 5])); 
console.log(mergeAndRemoveDuplicates([10, 20, 30], [20, 40, 50])); 
