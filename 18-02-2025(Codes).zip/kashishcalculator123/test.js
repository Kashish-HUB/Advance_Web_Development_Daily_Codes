var c =require('./index')
console.log(c.add(5,6))