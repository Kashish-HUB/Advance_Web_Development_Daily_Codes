{
    var a=10
}
console.log(a)


var arr=[10,20,30]
var arr1=new Array()
arr1[0]=10
arr1[1]=20
console.log(arr)
console.log(arr.concat(arr1))

arr1.push(200)
console.log(arr1)
arr1.pop()
console.log(arr1)
arr3=[10,20,30,40,50]
console.log(arr3.slice(2,4))
arr4=[10,20,30,40,50]
arr4.splice(2,0,25,35)

arr5=[1,23,36,40,50,60]
var even=arr5.filter(function(x){
    return x%2==0
})
console.log(even)

arr5=[1,23,36,40,50,60]
var even=arr5.every(function(x){
    return x%2==0
})
console.log(even)

arr5=[1,23,36,40,50,60]
var even=arr5.some(function(x){
    return x%2==0
})
console.log(even)







