//Readable stream
var fs=require('fs')
var data=''
var reader=fs.createReadStream('test.txt')

reader.setEncoding('utf8')
reader.on('data',(chunk)=>{
    data=chunk
})
reader.on('end',()=>{
    console.log(data)
})
reader.on('error',(err)=>{
    console.log(err)
})

//Writable Stream
var fs=require("fs");
var data='This is node.js class';
var writer=fs.createWriteStream('test.txt');

writer.write(data,'UTF8');
writer.end();

writer.on('finish',function(){
    console.log("Write completed");
});
writer.on('error',function(err){
    console.log(err);
});

//Piping data from one file to other file
/* var fs=require("fs");
var reader=fs.createReadStream('test.txt');
var writer=fs.createWriteStream('test1.txt');
writer.on('pipe',()=>{
    console.log('Something is piping into the writer');
});
reader.pipe(writer); */

/* //Unpiping data from one file to other file
var fs=require("fs");
var reader=fs.createReadStream('test.txt');
var writer=fs.createWriteStream('test1.txt');
writer.on('unpipe',()=>{
    console.log('Unpiping occurred');
});
reader.unpipe(writer); */

//Zip file using zlib
var zlib=require('zlib');
var fs=require('fs');
var gzip=zlib.createGzip();
var r=fs.createReadStream('test.txt');
var w =fs.createWriteStream('test.txt.gz');
r.pipe(gzip).pipe(w);

var zlib=require('zlib');
var fs=require('fs');
var defl=zlib.createDeflate();
var r=fs.createReadStream('test.txt');
var w =fs.createWriteStream('test.txt.gz');
r.pipe(defl).pipe(w);
