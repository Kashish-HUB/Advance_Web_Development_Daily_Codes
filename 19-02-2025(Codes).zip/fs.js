//Synchronus 
const fs=require('fs')
console.log("Started file reading sync")
data=fs.readFileSync('file.json')
parsed=JSON.parse(data)
console.log(parsed)
console.log("Sync reading done")

//Asynchronus
console.log("Started file reading async")
fs.readFile('file.json',(err,data)=>{
    if(err)
        throw err
    else
    parsed=JSON.parse(data)
console.log(parsed)
})
console.log("Async reading done")

//Write data
/* var datatowrite={
    name:"Kashish",
    age:30
}
var parsed1=JSON.stringify(datatowrite,null,2)
fs.writeFileSync('file1.json',parsed1)
fs.writeFile('file2.json',parsed1,(err)=>{
    if(err)
        throw err
})
 */
//Rename file
/* fs.renameSync('file1.json','filesync.json')
fs.rename('file2.json','fileasync.json',(err)=>{
    if(err)
        throw err
    else
    console.log("File renamed")
}) */

//Delete file
fs.unlinkSync('filesync.json')
fs.unlink('fileasync.json',(err)=>{
    if(err)
        throw err
    else
    console.log('File deleted')
})
