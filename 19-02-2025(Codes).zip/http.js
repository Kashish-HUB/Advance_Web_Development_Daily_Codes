var http=require('http');
var server=http.createServer(function(req,res)
{
    if(req.url=='/')
    {
        res.write('Welcome to index page');
        res.end();
    }
    else if(req.url=="/add")
    {
        function add(a,b){
            return a+b
        }
        res.write(`The result is ${add(4,5)}`);
        res.end();
    }
    else if(req.url=="/fact"){
        function fact(num){
            if(num==0 || num==1){
                return 1
            }
            else{
                return num*fact(num-1)
            }
        }
        res.write(`the fact is ${fact(5)}`)
        res.end()
    }
    else
    res.end('Invalid Request!');
});
server.listen(2020);
console.log('Server is running at port 2020')