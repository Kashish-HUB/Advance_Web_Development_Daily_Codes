var json='{"name":"Arwin","age":30}'
var json1={
    name:"Arwin",
    age:30
}
const jsontoobject=JSON.parse(json)
console.log(jsontoobject)
const objecttojson=JSON.stringify(json1,["name"],5)
console.log(objecttojson)